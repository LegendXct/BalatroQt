#include "roundendoverlay.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPixmap>

RoundEndOverlay::RoundEndOverlay(const QFont &cnFont, const QFont &pixelFont, QWidget *parent)
    : QWidget(parent), mCNFont(cnFont), mPixelFont(pixelFont)
{
    setAttribute(Qt::WA_StyledBackground, true);
    setStyleSheet("background: rgba(0, 0, 0, 100);");
    buildUi();
}

void RoundEndOverlay::buildUi()
{
    // 主面板:#374244 圆角,居中
    auto *panel = new QWidget(this);
    panel->setAttribute(Qt::WA_StyledBackground, true);
    panel->setObjectName("rePanel");
    panel->setStyleSheet(
        "QWidget#rePanel { background:#374244; border-radius:14px; "
        "                  border: 2px solid #4f6367; }"
        );
    panel->setFixedSize(560, 460);

    // 居中 panel
    auto *outer = new QVBoxLayout(this);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setAlignment(Qt::AlignCenter);
    outer->addWidget(panel);

    auto *vbl = new QVBoxLayout(panel);
    vbl->setContentsMargins(20, 18, 20, 18);
    vbl->setSpacing(12);

    // ── 顶部 cash out 按钮 ──
    mCashOutBtn = new QPushButton("提现: $0", panel);
    mCashOutBtn->setFixedHeight(60);
    QFont btnF = mCNFont; btnF.setPixelSize(28); btnF.setBold(true);
    mCashOutBtn->setFont(btnF);
    mCashOutBtn->setCursor(Qt::PointingHandCursor);
    mCashOutBtn->setStyleSheet(
        "QPushButton { background:#fda200; color:white; border:none;"
        "              border-radius: 10px; padding: 4px; }"
        "QPushButton:hover { background:#ffb730; }"
        );
    connect(mCashOutBtn, &QPushButton::clicked, this, &RoundEndOverlay::nextClicked);
    vbl->addWidget(mCashOutBtn);

    // 一个生成"明细行"的 lambda
    auto makeRow = [&](QLabel **leftNumOut, const QString &numColor,
                       const QString &desc, QLabel **rightSymOut) {
        auto *row = new QWidget(panel);
        auto *hbl = new QHBoxLayout(row);
        hbl->setContentsMargins(8, 0, 8, 0);
        hbl->setSpacing(8);

        // 左侧:大数字
        *leftNumOut = new QLabel("0", row);
        QFont nf = mCNFont; nf.setPixelSize(26); nf.setBold(true);
        (*leftNumOut)->setFont(nf);
        (*leftNumOut)->setStyleSheet(QString("color:%1; background:transparent;").arg(numColor));
        (*leftNumOut)->setFixedWidth(40);
        (*leftNumOut)->setAlignment(Qt::AlignCenter);
        hbl->addWidget(*leftNumOut);

        // 描述
        auto *descLbl = new QLabel(desc, row);
        QFont df = mCNFont; df.setPixelSize(14);
        descLbl->setFont(df);
        descLbl->setStyleSheet("color:white; background:transparent;");
        descLbl->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        hbl->addWidget(descLbl, 1);

        // 右侧 $$$$$
        *rightSymOut = new QLabel("", row);
        QFont sf = mCNFont; sf.setPixelSize(20); sf.setBold(true);
        (*rightSymOut)->setFont(sf);
        (*rightSymOut)->setStyleSheet("color:#f3b958; background:transparent;");
        (*rightSymOut)->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        hbl->addWidget(*rightSymOut);

        return row;
    };

    // ── 至少得分行(blind 主行) ──
    {
        auto *row = new QWidget(panel);
        auto *hbl = new QHBoxLayout(row);
        hbl->setContentsMargins(8, 0, 8, 0);
        hbl->setSpacing(8);

        // 盲注芯片(setData 时填充)
        mBlindChip = new QLabel(row);
        mBlindChip->setFixedSize(50, 50);
        mBlindChip->setStyleSheet("background:transparent;");
        hbl->addWidget(mBlindChip);

        // 中间:至少得分(竖排:小字+蓝芯片+红数字)
        auto *mid = new QWidget(row);
        auto *mvbl = new QVBoxLayout(mid);
        mvbl->setContentsMargins(0, 0, 0, 0);
        mvbl->setSpacing(2);
        mvbl->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

        QLabel *small = new QLabel("至少得分", mid);
        QFont sf = mCNFont; sf.setPixelSize(13);
        small->setFont(sf);
        small->setStyleSheet("color:white; background:transparent;");
        mvbl->addWidget(small);

        // 蓝芯片 + 红数字
        auto *numRow = new QWidget(mid);
        auto *numBl = new QHBoxLayout(numRow);
        numBl->setContentsMargins(0, 0, 0, 0);
        numBl->setSpacing(4);
        numBl->setAlignment(Qt::AlignLeft);

        QLabel *chipIcon = new QLabel(numRow);
        QPixmap chipsSheet(":/textures/images/chips.png");
        if (!chipsSheet.isNull()) {
            QPixmap pix = chipsSheet.copy(0, 0, 58, 58);
            chipIcon->setPixmap(pix.scaled(20, 20, Qt::KeepAspectRatio,
                                           Qt::SmoothTransformation));
        }
        chipIcon->setFixedSize(20, 20);
        chipIcon->setStyleSheet("background:transparent;");
        numBl->addWidget(chipIcon);

        mTargetLbl = new QLabel("0", numRow);
        QFont nf = mCNFont; nf.setPixelSize(22); nf.setBold(true);
        mTargetLbl->setFont(nf);
        mTargetLbl->setStyleSheet("color:#fe5f55; background:transparent;");
        numBl->addWidget(mTargetLbl);

        mvbl->addWidget(numRow);
        hbl->addWidget(mid, 1);

        // 右侧 $$$
        mBlindRewardSym = new QLabel("", row);
        QFont rf = mCNFont; rf.setPixelSize(20); rf.setBold(true);
        mBlindRewardSym->setFont(rf);
        mBlindRewardSym->setStyleSheet("color:#f3b958; background:transparent;");
        mBlindRewardSym->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        hbl->addWidget(mBlindRewardSym);

        vbl->addWidget(row);
    }

    // ── 虚线分隔 ──
    {
        QLabel *div = new QLabel(QString(48, '.'), panel);
        QFont dvf = mPixelFont; dvf.setPixelSize(14);
        div->setFont(dvf);
        div->setStyleSheet("color:white; background:transparent;");
        div->setAlignment(Qt::AlignCenter);
        vbl->addWidget(div);
    }

    // ── 出牌剩余 ──
    vbl->addWidget(makeRow(&mHandsNumLbl, "#009dff",
                           "剩余出牌次数(每次$1)", &mHandsRewardSym));

    // ── 利息 ──
    vbl->addWidget(makeRow(&mInterestNumLbl, "#f3b958",
                           "每$5获得1利息(最高 5)", &mInterestRewardSym));

    vbl->addStretch();
}

void RoundEndOverlay::setData(int blindChipRow, int targetScore, int blindReward,
                              int handsLeft, int handBonus, int interest)
{
    int total = blindReward + handBonus + interest;
    mCashOutBtn->setText(QString("提现: $%1").arg(total));

    QPixmap sheet(":/textures/images/BlindChips.png");
    if (!sheet.isNull()) {
        QPixmap pix = sheet.copy(0, blindChipRow * 68, 68, 68);
        mBlindChip->setPixmap(pix.scaled(50, 50, Qt::KeepAspectRatio,
                                         Qt::SmoothTransformation));
    }

    mTargetLbl->setText(QString::number(targetScore));
    mBlindRewardSym->setText(QString(blindReward, '$'));

    mHandsNumLbl->setText(QString::number(handsLeft));
    mHandsRewardSym->setText(QString(handBonus, '$'));

    mInterestNumLbl->setText(QString::number(interest));
    mInterestRewardSym->setText(QString(interest, '$'));
}
